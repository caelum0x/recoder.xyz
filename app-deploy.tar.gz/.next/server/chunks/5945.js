exports.id=5945,exports.ids=[5945],exports.modules={7673:(a,b,c)=>{"use strict";c.d(b,{J1:()=>k,b7:()=>l,kH:()=>j,v4:()=>i});var d=c(36421);let e=process.env.EMAIL_FROM||process.env.SMTP_FROM||"noreply@recoder.xyz",f="Recoder.xyz",g=d.createTransport({host:process.env.SMTP_HOST||"smtp.gmail.com",port:parseInt(process.env.SMTP_PORT||"587"),secure:!1,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});async function h({to:a,subject:b,html:c,text:d}){if(process.env.RESEND_API_KEY)try{let g=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${process.env.RESEND_API_KEY}`},body:JSON.stringify({from:`${f} <${e}>`,to:[a],subject:b,html:c,text:d||c.replace(/<[^>]*>/g,"")})});if(!g.ok){let a=await g.json();throw Error(`Resend API error: ${JSON.stringify(a)}`)}let h=await g.json();return console.log("✅ Email sent via Resend:",h.id),{success:!0,messageId:h.id}}catch(a){return console.error("❌ Resend email error:",a),{success:!1,error:a}}try{let h=await g.sendMail({from:`${f} <${e}>`,to:a,subject:b,html:c,text:d||c.replace(/<[^>]*>/g,"")});return console.log("✅ Email sent via SMTP:",h.messageId),{success:!0,messageId:h.messageId}}catch(a){return console.error("❌ SMTP email error:",a),{success:!1,error:a}}}async function i(a,b){return h({to:a,subject:"Welcome to Recoder.xyz! \uD83D\uDE80",html:`
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Welcome to Recoder.xyz!</h1>
          </div>
          <div class="content">
            <h2>Hi ${b}! 👋</h2>
            <p>Thank you for joining Recoder.xyz - the AI-powered development platform that generates <strong>real, production-ready code</strong>.</p>
            
            <h3>Get Started:</h3>
            <ul>
              <li><strong>Dashboard:</strong> Access your personal dashboard to manage projects</li>
              <li><strong>CLI Tools:</strong> Install our CLI for terminal-based development</li>
              <li><strong>AI Models:</strong> Choose from Claude, GPT-4, Gemini, and more</li>
              <li><strong>Web Platform:</strong> Use our browser-based development environment</li>
            </ul>
            
            <a href="${process.env.NEXTAUTH_URL||"https://recoder.xyz"}/dashboard" class="button">Go to Dashboard</a>
            
            <p>Need help? Check out our <a href="${process.env.NEXTAUTH_URL||"https://recoder.xyz"}/docs">documentation</a> or reach out to our support team.</p>
            
            <p>Happy coding! 🎉</p>
          </div>
          <div class="footer">
            <p>\xa9 2024 Recoder.xyz. All rights reserved.</p>
            <p>Questions? Contact us at support@recoder.xyz</p>
          </div>
        </div>
      </body>
    </html>
  `})}async function j(a,b){let c=`${process.env.NEXTAUTH_URL||"https://recoder.xyz"}/api/auth/verify?token=${b}`;return h({to:a,subject:"Verify Your Email Address",html:`
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #667eea; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .code { background: #e0e0e0; padding: 10px; font-family: monospace; font-size: 16px; letter-spacing: 2px; text-align: center; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Verify Your Email</h1>
          </div>
          <div class="content">
            <p>Please verify your email address by clicking the button below:</p>
            <a href="${c}" class="button">Verify Email</a>
            <p>Or copy and paste this link into your browser:</p>
            <div class="code">${c}</div>
            <p>This link will expire in 24 hours.</p>
            <p>If you didn't create an account with Recoder.xyz, please ignore this email.</p>
          </div>
        </div>
      </body>
    </html>
  `})}async function k(a,b){let c=`${process.env.NEXTAUTH_URL||"https://recoder.xyz"}/auth/reset-password?token=${b}`;return h({to:a,subject:"Reset Your Password",html:`
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #667eea; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .button { display: inline-block; padding: 12px 30px; background: #dc2626; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Reset Your Password</h1>
          </div>
          <div class="content">
            <p>We received a request to reset your password. Click the button below to create a new password:</p>
            <a href="${c}" class="button">Reset Password</a>
            <p>This link will expire in 1 hour.</p>
            <p>If you didn't request a password reset, please ignore this email and your password will remain unchanged.</p>
          </div>
        </div>
      </body>
    </html>
  `})}async function l(a,b){return h({to:a,subject:"Your Temporary Password - Recoder.xyz",html:`
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #f97316 0%, #9333ea 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .password-box { background: #1a1a1a; color: #f97316; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0; border: 2px solid #333; }
          .password { font-size: 32px; font-weight: bold; letter-spacing: 3px; font-family: 'Courier New', monospace; }
          .button { display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #f97316 0%, #9333ea 100%); color: white; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
          .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚀 Welcome to Recoder.xyz!</h1>
          </div>
          <div class="content">
            <h2>Your Account is Ready</h2>
            <p>Your account has been created successfully. Here's your temporary password:</p>

            <div class="password-box">
              <div style="font-size: 12px; color: #999; margin-bottom: 10px;">TEMPORARY PASSWORD</div>
              <div class="password">${b}</div>
            </div>

            <div class="warning">
              <strong>⚠️ Important Security Notice:</strong><br>
              Please change this password immediately after your first login. This temporary password should not be shared with anyone.
            </div>

            <a href="https://recoder.xyz/auth/signin" class="button">Sign In Now</a>

            <h3>Getting Started:</h3>
            <ul>
              <li>Sign in with your email and temporary password</li>
              <li>Change your password in settings</li>
              <li>Explore our AI-powered code generation</li>
              <li>Access all platforms with one account</li>
            </ul>

            <p>If you didn't create an account, please contact support at support@recoder.xyz</p>
          </div>
        </div>
      </body>
    </html>
  `,text:`
Welcome to Recoder.xyz!

Your account has been created successfully.

TEMPORARY PASSWORD: ${b}

⚠️ Important: Please change this password immediately after your first login.

Sign in at: https://recoder.xyz/auth/signin

Getting Started:
- Sign in with your email and temporary password
- Change your password in settings
- Explore our AI-powered code generation
- Access all platforms with one account

If you didn't create an account, please contact support at support@recoder.xyz
  `})}},28430:()=>{},48693:(a,b,c)=>{"use strict";c.d(b,{cK:()=>g,zR:()=>f});var d=c(55511),e=c(96330);let f=global.prisma||new e.PrismaClient({log:["error"],datasources:{db:{url:process.env.DATABASE_URL}}});{let a=async()=>{await f.$disconnect()};process.on("beforeExit",a),process.on("SIGINT",a),process.on("SIGTERM",a)}let g={async findOrCreateUser(a,b,c){let e=await f.users.findUnique({where:{email:a}});return e||(e=await f.users.create({data:{id:d.randomUUID(),email:a,name:b,subscriptionPlan:"free",subscriptionStatus:"active",emailVerified:!!c,updatedAt:new Date}}),await f.user_quota.create({data:{userId:e.id,requestsLimit:1e3,requestsUsed:0,periodStart:new Date,periodEnd:new Date(Date.now()+2592e6)}})),e},async createAuthCode(a,b,c,e,g){let h=`ac_${d.randomUUID()}`;return await f.authCode.create({data:{id:d.randomUUID(),code:h,userId:a,clientId:b,redirectUri:c,scope:e,state:g,expiresAt:new Date(Date.now()+6e5)}}),h},async validateAuthCode(a){let b=await f.authCode.findUnique({where:{code:a},include:{user:!0}});return!b||b.used||b.expiresAt<new Date?null:(await f.authCode.update({where:{code:a},data:{used:!0}}),b)},async createDeviceFlow(a,b){let c=`dc_${d.randomUUID()}`,e=function(){let a="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",b="";for(let c=0;c<8;c++)b+=a.charAt(Math.floor(Math.random()*a.length));return b.slice(0,4)+"-"+b.slice(4)}();return await f.deviceCode.create({data:{deviceCode:c,userCode:e,clientId:a,scope:b,status:"pending",expiresAt:new Date(Date.now()+9e5)}})},async authorizeDevice(a,b){let c=await f.deviceCode.findUnique({where:{userCode:a.toUpperCase()}});return!c||c.expiresAt<new Date||"pending"!==c.status?null:await f.deviceCode.update({where:{userCode:a.toUpperCase()},data:{userId:b,status:"authorized"}})},async pollDeviceCode(a){let b=await f.deviceCode.findUnique({where:{deviceCode:a},include:{user:!0}});return b?b.expiresAt<new Date?{status:"expired"}:"denied"===b.status?{status:"denied"}:"pending"===b.status?{status:"pending"}:{status:"authorized",userId:b.userId,user:b.user}:{status:"invalid"}},async createCLISession(a,b){let c=`rct_${d.randomUUID()}`,e=`rcr_${d.randomUUID()}`;return await f.cli_sessions.create({data:{id:d.randomUUID(),userId:a,deviceId:d.randomUUID(),deviceName:b||"CLI",deviceType:"cli",accessToken:c,refreshToken:e,expiresAt:new Date(Date.now()+2592e6)}})},async validateSession(a){let b=await f.cli_sessions.findFirst({where:{OR:[{accessToken:a},{refreshToken:a}],isActive:!0,expiresAt:{gt:new Date}},include:{users:!0}});return b&&await f.cli_sessions.update({where:{id:b.id},data:{lastUsedAt:new Date}}),b},async refreshSession(a){let b=await f.cli_sessions.findUnique({where:{refreshToken:a},include:{users:!0}});if(!b||!b.isActive||b.expiresAt<new Date)return null;let c=`rct_${d.randomUUID()}`;return await f.cli_sessions.update({where:{id:b.id},data:{accessToken:c,lastUsedAt:new Date},include:{users:!0}})},async createApiKey(a,b,c){let e=`key_${d.randomUUID()}`,g=`rck_${d.randomUUID()}`,i=await h(g);return await f.api_keys.create({data:{id:d.randomUUID(),userId:a,keyHash:i,keyPrefix:g.substring(0,12),name:b,permissions:c,updatedAt:new Date}}),{keyId:e,apiKey:g}},async validateApiKey(a){let b=await h(a),c=await f.api_keys.findFirst({where:{keyHash:b},include:{users:!0}});return!c||!c.isActive||c.expiresAt&&c.expiresAt<new Date?null:(await f.api_keys.update({where:{id:c.id},data:{lastUsedAt:new Date,usageCount:{increment:1}}}),c)},async recordUsage(a,b,c){await f.usage_records.create({data:{id:d.randomUUID(),userId:a,requestType:b,type:"api_usage",...c}})},async cleanupExpired(){let a=new Date;await f.authCode.deleteMany({where:{OR:[{expiresAt:{lt:a}},{used:!0,createdAt:{lt:new Date(a.getTime()-864e5)}}]}}),await f.deviceCode.updateMany({where:{expiresAt:{lt:a},status:"pending"},data:{status:"expired"}}),await f.deviceCode.deleteMany({where:{status:{in:["completed","expired"]},createdAt:{lt:new Date(a.getTime()-864e5)}}}),await f.cli_sessions.updateMany({where:{expiresAt:{lt:a},isActive:!0},data:{isActive:!1}})}};async function h(a){let b=new TextEncoder().encode(a);return Array.from(new Uint8Array(await d.subtle.digest("SHA-256",b))).map(a=>a.toString(16).padStart(2,"0")).join("")}},67750:()=>{}};